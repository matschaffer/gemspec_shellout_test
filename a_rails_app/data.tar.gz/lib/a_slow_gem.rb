require "a_slow_gem/version"

module ASlowGem
  # Your code goes here...
end
